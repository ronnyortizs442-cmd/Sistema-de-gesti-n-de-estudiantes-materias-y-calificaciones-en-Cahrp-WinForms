using System;
using System.Windows.Forms;
using SistemaNotas.Formularios;

namespace SistemaNotas
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new FrmEstudiantes());
        }
    }
}