using System;
using System.Windows.Forms;
using SistemaNotas.Datos;
using System.Data;

namespace SistemaNotas.Formularios
{
    public partial class FrmCalificaciones : Form
    {
        private ComboBox cmbEstudiante, cmbMateria;
        private TextBox txtC1, txtC2, txtC3, txtC4, txtExamen;
        private Button btnGuardar;
        private DataGridView dgvCalificaciones;

        public FrmCalificaciones()
        {
            InitializeComponent();
            CargarCombos();
            Listar();
        }

        private void InitializeComponent()
        {
            this.Text = "Calificaciones";
            this.Width = 900;
            this.Height = 600;

            cmbEstudiante = new ComboBox { Left = 120, Top = 10, Width = 300 };
            cmbMateria = new ComboBox { Left = 120, Top = 40, Width = 300 };

            txtC1 = new TextBox { Left = 120, Top = 80, Width = 80 };
            txtC2 = new TextBox { Left = 220, Top = 80, Width = 80 };
            txtC3 = new TextBox { Left = 320, Top = 80, Width = 80 };
            txtC4 = new TextBox { Left = 420, Top = 80, Width = 80 };
            txtExamen = new TextBox { Left = 520, Top = 80, Width = 80 };

            btnGuardar = new Button { Left = 120, Top = 120, Text = "Guardar" };
            dgvCalificaciones = new DataGridView { Left = 10, Top = 160, Width = 860, Height = 380 };

            this.Controls.AddRange(new Control[] {
                new Label { Left = 10, Top = 10, Text = "Estudiante:" },
                cmbEstudiante,
                new Label { Left = 10, Top = 40, Text = "Materia:" },
                cmbMateria,
                new Label { Left = 10, Top = 80, Text = "C1,C2,C3,C4,Examen:" },
                txtC1, txtC2, txtC3, txtC4, txtExamen,
                btnGuardar, dgvCalificaciones
            });

            btnGuardar.Click += BtnGuardar_Click;
        }

        void CargarCombos()
        {
            DataTable tE = EstudianteDAL.Listar();
            cmbEstudiante.DataSource = tE;
            cmbEstudiante.DisplayMember = "Nombre";
            cmbEstudiante.ValueMember = "EstudianteID";

            DataTable tM = MateriaDAL.Listar();
            cmbMateria.DataSource = tM;
            cmbMateria.DisplayMember = "Nombre";
            cmbMateria.ValueMember = "MateriaID";
        }

        void Listar()
        {
            dgvCalificaciones.DataSource = CalificacionDAL.Listar();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            decimal c1 = decimal.TryParse(txtC1.Text, out decimal _c1) ? _c1 : 0;
            decimal c2 = decimal.TryParse(txtC2.Text, out decimal _c2) ? _c2 : 0;
            decimal c3 = decimal.TryParse(txtC3.Text, out decimal _c3) ? _c3 : 0;
            decimal c4 = decimal.TryParse(txtC4.Text, out decimal _c4) ? _c4 : 0;
            decimal ex = decimal.TryParse(txtExamen.Text, out decimal _ex) ? _ex : 0;

            CalificacionDAL.Insertar(
                Convert.ToInt32(cmbEstudiante.SelectedValue),
                Convert.ToInt32(cmbMateria.SelectedValue),
                c1, c2, c3, c4, ex
            );

            MessageBox.Show("Calificación guardada");
            Listar();
        }
    }
}