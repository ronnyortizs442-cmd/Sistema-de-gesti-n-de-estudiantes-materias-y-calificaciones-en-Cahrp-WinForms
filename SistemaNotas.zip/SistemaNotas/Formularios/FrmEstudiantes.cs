using System;
using System.Windows.Forms;
using SistemaNotas.Datos;

namespace SistemaNotas.Formularios
{
    public partial class FrmEstudiantes : Form
    {
        // Para simplicidad este formulario crea controles por código en el constructor.
        private DataGridView dgvEstudiantes;
        private TextBox txtId, txtNombre, txtCorreo, txtMatricula;
        private Button btnGuardar, btnActualizar, btnEliminar;

        public FrmEstudiantes()
        {
            InitializeComponent();
            Listar();
        }

        private void InitializeComponent()
        {
            this.Text = "Estudiantes";
            this.Width = 800;
            this.Height = 600;

            dgvEstudiantes = new DataGridView { Left = 10, Top = 200, Width = 760, Height = 340 };
            txtId = new TextBox { Left = 100, Top = 10, Width = 100, ReadOnly = true };
            txtNombre = new TextBox { Left = 100, Top = 40, Width = 250 };
            txtCorreo = new TextBox { Left = 100, Top = 70, Width = 250 };
            txtMatricula = new TextBox { Left = 100, Top = 100, Width = 150 };

            btnGuardar = new Button { Left = 100, Top = 140, Text = "Guardar" };
            btnActualizar = new Button { Left = 200, Top = 140, Text = "Actualizar" };
            btnEliminar = new Button { Left = 320, Top = 140, Text = "Eliminar" };

            this.Controls.AddRange(new Control[] {
                new Label { Left = 10, Top = 10, Text = "ID:" },
                txtId,
                new Label { Left = 10, Top = 40, Text = "Nombre:" },
                txtNombre,
                new Label { Left = 10, Top = 70, Text = "Correo:" },
                txtCorreo,
                new Label { Left = 10, Top = 100, Text = "Matrícula:" },
                txtMatricula,
                btnGuardar, btnActualizar, btnEliminar, dgvEstudiantes
            });

            btnGuardar.Click += BtnGuardar_Click;
            btnActualizar.Click += BtnActualizar_Click;
            btnEliminar.Click += BtnEliminar_Click;
            dgvEstudiantes.CellClick += DgvEstudiantes_CellClick;
        }

        void Listar()
        {
            dgvEstudiantes.DataSource = EstudianteDAL.Listar();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            EstudianteDAL.Insertar(txtNombre.Text, txtCorreo.Text, txtMatricula.Text);
            MessageBox.Show("Estudiante guardado");
            Listar();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtId.Text, out int id))
            {
                EstudianteDAL.Actualizar(id, txtNombre.Text, txtCorreo.Text, txtMatricula.Text);
                MessageBox.Show("Estudiante actualizado");
                Listar();
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtId.Text, out int id))
            {
                EstudianteDAL.Eliminar(id);
                MessageBox.Show("Estudiante eliminado");
                Listar();
            }
        }

        private void DgvEstudiantes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvEstudiantes.Rows[e.RowIndex];
                txtId.Text = row.Cells["EstudianteID"].Value?.ToString();
                txtNombre.Text = row.Cells["Nombre"].Value?.ToString();
                txtCorreo.Text = row.Cells["Correo"].Value?.ToString();
                txtMatricula.Text = row.Cells["Matricula"].Value?.ToString();
            }
        }
    }
}