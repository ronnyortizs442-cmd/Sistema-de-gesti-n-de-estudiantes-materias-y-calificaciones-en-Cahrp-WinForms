using System;
using System.Windows.Forms;
using SistemaNotas.Datos;

namespace SistemaNotas.Formularios
{
    public partial class FrmMaterias : Form
    {
        private DataGridView dgvMaterias;
        private TextBox txtNombre, txtDescripcion;
        private Button btnGuardar;

        public FrmMaterias()
        {
            InitializeComponent();
            Listar();
        }

        private void InitializeComponent()
        {
            this.Text = "Materias";
            this.Width = 700;
            this.Height = 500;

            dgvMaterias = new DataGridView { Left = 10, Top = 120, Width = 660, Height = 320 };
            txtNombre = new TextBox { Left = 100, Top = 10, Width = 300 };
            txtDescripcion = new TextBox { Left = 100, Top = 40, Width = 400 };

            btnGuardar = new Button { Left = 100, Top = 70, Text = "Guardar" };

            this.Controls.AddRange(new Control[] {
                new Label { Left = 10, Top = 10, Text = "Nombre:" },
                txtNombre,
                new Label { Left = 10, Top = 40, Text = "Descripción:" },
                txtDescripcion,
                btnGuardar, dgvMaterias
            });

            btnGuardar.Click += BtnGuardar_Click;
        }

        void Listar()
        {
            dgvMaterias.DataSource = MateriaDAL.Listar();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            MateriaDAL.Insertar(txtNombre.Text, txtDescripcion.Text);
            MessageBox.Show("Materia registrada");
            Listar();
        }
    }
}