SistemaNotas - Proyecto WinForms (generado)
==========================================

Contenido:
- Proyecto .NET 6 WinForms con capas de Datos y Formularios.
- Conexión ADO.NET a SQL Server (ajusta la cadena de conexión en Datos/Conexion.cs).
- Formularios creados por código (sin archivos Designer) para facilitar la apertura.
- Base de datos esperada: SistemaNotasDB con las tablas Estudiante, Materia y Calificacion (tal como las proporcionaste).

Instrucciones:
1. Asegúrate de tener .NET 6 SDK y Visual Studio 2022 (o superior) con soporte WinForms.
2. Restaura/abre la solución en Visual Studio.
3. Si abre problemas con Windows Forms API en .NET 6, puedes crear un proyecto WinForms y reemplazar los archivos .cs con los contenidos de la carpeta 'SistemaNotas'.
4. Ajusta la cadena de conexión en Datos/Conexion.cs si usas autenticación SQL Server o servidor diferente.
5. Ejecuta las instrucciones SQL (archivo SQL no incluido) para crear la base de datos y tablas.

Nota:
- Los formularios fueron creados por código (sin archivos .Designer.cs). Si prefieres, puedo generar versiones con Designer y recursos.