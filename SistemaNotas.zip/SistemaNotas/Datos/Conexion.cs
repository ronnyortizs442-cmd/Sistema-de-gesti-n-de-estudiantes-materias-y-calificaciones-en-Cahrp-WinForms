using System.Data.SqlClient;

namespace SistemaNotas.Datos
{
    public class Conexion
    {
        public static SqlConnection ObtenerConexion()
        {
            // Ajusta la cadena de conexión según tu entorno.
            string connection = "Server=.;Database=SistemaNotasDB;Integrated Security=true;";
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();
            return conn;
        }
    }
}