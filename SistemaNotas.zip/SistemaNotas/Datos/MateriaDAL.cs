using System.Data;
using System.Data.SqlClient;

namespace SistemaNotas.Datos
{
    public class MateriaDAL
    {
        public static void Insertar(string nombre, string descripcion)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = "INSERT INTO Materia (Nombre,Descripcion) VALUES (@n,@d)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@d", descripcion ?? (object)DBNull.Value);
                cmd.ExecuteNonQuery();
            }
        }

        public static DataTable Listar()
        {
            DataTable tabla = new DataTable();
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = "SELECT * FROM Materia ORDER BY MateriaID DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                da.Fill(tabla);
            }
            return tabla;
        }
    }
}