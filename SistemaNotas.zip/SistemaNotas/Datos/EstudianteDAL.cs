using System;
using System.Data;
using System.Data.SqlClient;

namespace SistemaNotas.Datos
{
    public class EstudianteDAL
    {
        public static void Insertar(string nombre, string correo, string matricula)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = "INSERT INTO Estudiante (Nombre, Correo, Matricula) VALUES (@n,@c,@m)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@c", correo ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@m", matricula ?? (object)DBNull.Value);
                cmd.ExecuteNonQuery();
            }
        }

        public static void Actualizar(int id, string nombre, string correo, string matricula)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = "UPDATE Estudiante SET Nombre=@n, Correo=@c, Matricula=@m WHERE EstudianteID=@id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@c", correo ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@m", matricula ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
        }

        public static void Eliminar(int id)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = "DELETE FROM Estudiante WHERE EstudianteID=@id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
        }

        public static DataTable Listar()
        {
            DataTable tabla = new DataTable();
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = "SELECT * FROM Estudiante ORDER BY EstudianteID DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                da.Fill(tabla);
            }
            return tabla;
        }
    }
}