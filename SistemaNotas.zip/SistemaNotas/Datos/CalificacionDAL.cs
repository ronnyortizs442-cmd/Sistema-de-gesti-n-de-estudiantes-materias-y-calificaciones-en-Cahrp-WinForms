using System.Data;
using System.Data.SqlClient;

namespace SistemaNotas.Datos
{
    public class CalificacionDAL
    {
        public static void Insertar(int estudiante, int materia, decimal c1, decimal c2, decimal c3, decimal c4, decimal examen)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = @"INSERT INTO Calificacion 
                    (EstudianteID, MateriaID, Cal1, Cal2, Cal3, Cal4, Examen) 
                    VALUES (@e,@m,@c1,@c2,@c3,@c4,@ex)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@e", estudiante);
                cmd.Parameters.AddWithValue("@m", materia);
                cmd.Parameters.AddWithValue("@c1", c1);
                cmd.Parameters.AddWithValue("@c2", c2);
                cmd.Parameters.AddWithValue("@c3", c3);
                cmd.Parameters.AddWithValue("@c4", c4);
                cmd.Parameters.AddWithValue("@ex", examen);
                cmd.ExecuteNonQuery();
            }
        }

        public static DataTable Listar()
        {
            DataTable tabla = new DataTable();
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                string query = @"SELECT c.CalificacionID, e.Nombre AS Estudiante, m.Nombre AS Materia,
                                c.Cal1, c.Cal2, c.Cal3, c.Cal4, c.Examen, 
                                c.Total, c.Clasificacion, c.Estado
                                FROM Calificacion c
                                INNER JOIN Estudiante e ON c.EstudianteID = e.EstudianteID
                                INNER JOIN Materia m ON c.MateriaID = m.MateriaID
                                ORDER BY c.CalificacionID DESC";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                da.Fill(tabla);
            }
            return tabla;
        }
    }
}