﻿using $safeprojectname$.Entidad;
using Microsoft.Data.SqlClient;
using System.Data;

namespace $safeprojectname$.Datos
{
    public class MateriaDAL: Conexion
    {
        Estudiante estudiante = new Estudiante();

        public void Insertar(string Nombre, string Descripcion)
        {
            SqlConnection conn = CrearConexion();
            conn.Open();
            SqlCommand cmd = new SqlCommand(
           "INSERT INTO Materia (Nombre, Descripcion) VALUES (@Nombre, @Descripcion)", conn);
            cmd.Parameters.AddWithValue("@Nombre", Nombre);
            cmd.Parameters.AddWithValue("@Descripcion", Descripcion);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

      
        public DataTable Listar()
        {
            SqlConnection conn = CrearConexion();
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Materia", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public void Eliminar(int MateriaID)
        {
            SqlConnection conn = CrearConexion();
            conn.Open();
            SqlCommand cmd = new SqlCommand(
           "DELETE FROM Materia WHERE MateriaID = @MateriaID", conn);
            cmd.Parameters.AddWithValue("@MateriaID", MateriaID);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void Actualizar(int MateriaID, string Nombre, string Descripcion)
        {
            SqlConnection conn = CrearConexion();
            conn.Open();
            SqlCommand cmd = new SqlCommand(
                "UPDATE Materia SET Nombre = @Nombre, Descripcion = @Descripcion WHERE MateriaID = @MateriaID", conn);
            cmd.Parameters.AddWithValue("@MateriaID", MateriaID);
            cmd.Parameters.AddWithValue("@Nombre", Nombre);
            cmd.Parameters.AddWithValue("@Descripcion", Descripcion);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }   
}

