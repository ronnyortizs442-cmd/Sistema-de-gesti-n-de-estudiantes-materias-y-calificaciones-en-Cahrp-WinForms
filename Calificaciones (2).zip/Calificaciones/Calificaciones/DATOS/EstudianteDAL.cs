﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace $safeprojectname$.Datos
{
    public class EstudianteDAL : Conexion
    {

        public DataTable Listar()
        {
            SqlConnection conn = CrearConexion();
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Estudiante", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public void Guardar( string Nombre, string Correo, string Matricula)
        {
            SqlConnection conn = CrearConexion();
            conn.Open();
            SqlCommand cmd = new SqlCommand(
           "INSERT INTO Estudiante (Nombre, Correo, Matricula) VALUES ( @Nombre, @Correo, @Matricula)", conn);

            cmd.Parameters.AddWithValue("@Nombre", Nombre);
            cmd.Parameters.AddWithValue("@Correo", Correo);
            cmd.Parameters.AddWithValue("@Matricula", Matricula);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void Actualizar(int Id, string Nombre, string Matricula, string Correo)
        {
            using (SqlConnection conn = CrearConexion())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(
                    "UPDATE Estudiante SET Nombre=@Nombre, Matricula=@Matricula, Correo=@Correo WHERE EstudianteID=@Id", conn);

                cmd.Parameters.AddWithValue("@Id", Id);
                cmd.Parameters.AddWithValue("@Nombre", Nombre);
                cmd.Parameters.AddWithValue("@Matricula", Matricula);
                cmd.Parameters.AddWithValue("@Correo", Correo);

                cmd.ExecuteNonQuery();
            }
        }


        public void Eliminar(int EstudianteID)
        {
            using (SqlConnection conn = CrearConexion())
            {
                conn.Open();

                SqlCommand cmd1 = new SqlCommand(
                    "DELETE FROM Calificacion WHERE EstudianteID = @EstudianteID", conn);
                cmd1.Parameters.AddWithValue("@EstudianteID", EstudianteID);
                cmd1.ExecuteNonQuery();

                SqlCommand cmd2 = new SqlCommand(
                    "DELETE FROM Estudiante WHERE EstudianteID = @EstudianteID", conn);
                cmd2.Parameters.AddWithValue("@EstudianteID", EstudianteID);
                cmd2.ExecuteNonQuery();
            }
        }
    }

}

