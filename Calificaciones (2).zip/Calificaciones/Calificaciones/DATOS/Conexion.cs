﻿using Microsoft.Data.SqlClient;

namespace $safeprojectname$.Datos
{
    public class Conexion
    {
            private string cadena = "Data Source=RONNY\\SQLEXPRESS;Initial Catalog=SistemaNotasdb;Integrated Security=True;TrustServerCertificate=True;";

            public SqlConnection CrearConexion()
            {
                SqlConnection conn = new SqlConnection(cadena);
                return conn;
            }

    }
}
