﻿using Microsoft.Data.SqlClient;
using System.Data;


namespace $safeprojectname$.Datos
{
    public class CalificacionDAL : Conexion
    {

        public void Insertar(int EstudianteID, int MateriaID, decimal C1, decimal C2, decimal C3, decimal C4, decimal Examen)
        {
            using (SqlConnection conn = CrearConexion())
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Calificacion (EstudianteID, MateriaID, Cal1, Cal2, Cal3, Cal4, Examen) " +
                    "VALUES (@EstudianteID, @MateriaID, @C1, @C2, @C3, @C4, @Examen)", conn);

                cmd.Parameters.AddWithValue("@EstudianteID", EstudianteID);
                cmd.Parameters.AddWithValue("@MateriaID", MateriaID);
                cmd.Parameters.AddWithValue("@C1", C1);
                cmd.Parameters.AddWithValue("@C2", C2);
                cmd.Parameters.AddWithValue("@C3", C3);
                cmd.Parameters.AddWithValue("@C4", C4);
                cmd.Parameters.AddWithValue("@Examen", Examen);

                cmd.ExecuteNonQuery();
            }
        }


        public DataTable Listar()
        {
            SqlConnection conn = CrearConexion();
            SqlDataAdapter da = new SqlDataAdapter(@"SELECT c.CalificacionID, e.Nombre AS Estudiante, m.Nombre AS Materia,
                                c.Cal1, c.Cal2, c.Cal3, c.Cal4, c.Examen, 
                                c.Total, c.Clasificacion, c.Estado
                                FROM Calificacion c
                                INNER JOIN Estudiante e ON c.EstudianteID = e.EstudianteID
                                INNER JOIN Materia m ON c.MateriaID = m.MateriaID
                                ORDER BY c.CalificacionID DESC", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }


        public void Actualizar(int CalificacionID, int EstudianteID, int MateriaID, decimal C1, decimal C2, decimal C3, decimal C4, decimal Examen)
        {
            using (SqlConnection conn = CrearConexion())
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Calificacion SET 
                EstudianteID = @EstudianteID,
                MateriaID = @MateriaID,
                Cal1 = @C1,
                Cal2 = @C2,
                Cal3 = @C3,
                Cal4 = @C4,
                Examen = @Examen
              WHERE CalificacionID = @CalificacionID", conn);

                cmd.Parameters.AddWithValue("@CalificacionID", CalificacionID);
                cmd.Parameters.AddWithValue("@EstudianteID", EstudianteID);
                cmd.Parameters.AddWithValue("@MateriaID", MateriaID);
                cmd.Parameters.AddWithValue("@C1", C1);
                cmd.Parameters.AddWithValue("@C2", C2);
                cmd.Parameters.AddWithValue("@C3", C3);
                cmd.Parameters.AddWithValue("@C4", C4);
                cmd.Parameters.AddWithValue("@Examen", Examen);

                cmd.ExecuteNonQuery();
            }
        }

        public void Eliminar(int CalificacionID)
        {
            using (SqlConnection conn = CrearConexion())
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(
                    "DELETE FROM Calificacion WHERE CalificacionID = @CalificacionID", conn);

                cmd.Parameters.AddWithValue("@CalificacionID", CalificacionID);

                cmd.ExecuteNonQuery();
            }
        }
    }
}

