﻿using $safeprojectname$.Forms;
using $safeprojectname$.Datos;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace $safeprojectname$.Formularios
{
    public partial class FrmMenu : Form
    {
        CalificacionDAL calificacionDAL = new CalificacionDAL();

        public FrmMenu()
        {
            InitializeComponent();

        }

        private void estudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void estudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {


        }

        private void materiasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void FrmMenu_Load(object sender, EventArgs e)
        {
            dgvInicio.DataSource = new CalificacionDAL().Listar();
            dgvInicio.ClearSelection();
            dgvInicio.CurrentCell = null;



        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMenu frmMenu = new FrmMenu();
            frmMenu.Show();
            this.Hide();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void estudiantesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void inicioToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void estudiantesToolStripMenuItem_Click_2(object sender, EventArgs e)
        {
            FrmEstudiante frmEstudiante = new FrmEstudiante();
            frmEstudiante.Show();
            this.Hide();
        }

        private void estudianteToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FrmEstudiante frmEstudiante = new FrmEstudiante();
            frmEstudiante.Show();
            this.Hide();
        }

        private void materiasToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FrmMaterias frmMaterias = new FrmMaterias();
            frmMaterias.Show();
            this.Hide();
        }

        private void calificacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCalificaciones frmCalificaciones = new FrmCalificaciones();
            frmCalificaciones.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dgvInicio_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            if (dgvInicio.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.");
                return;
            }

            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Archivo CSV (*.csv)|*.csv";
            saveFile.Title = "Exportar calificaciones";
            saveFile.FileName = "$safeprojectname$.csv";

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(saveFile.FileName))
                    {
                        for (int i = 0; i < dgvInicio.Columns.Count; i++)
                        {
                            sw.Write(dgvInicio.Columns[i].HeaderText);

                            if (i < dgvInicio.Columns.Count - 1)
                                sw.Write(",");
                        }

                        sw.WriteLine();

                        foreach (DataGridViewRow row in dgvInicio.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                for (int i = 0; i < dgvInicio.Columns.Count; i++)
                                {
                                    sw.Write(row.Cells[i].Value);

                                    if (i < dgvInicio.Columns.Count - 1)
                                        sw.Write(",");
                                }
                                sw.WriteLine();
                            }
                        }
                    }

                    MessageBox.Show("Datos exportados correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al exportar: " + ex.Message);
                }
            }
        }
    }
}
