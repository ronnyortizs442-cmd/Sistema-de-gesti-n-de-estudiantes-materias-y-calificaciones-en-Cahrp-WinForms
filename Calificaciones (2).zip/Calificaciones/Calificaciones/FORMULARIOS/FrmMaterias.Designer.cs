﻿namespace $safeprojectname$.Formularios
{
    partial class FrmMaterias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEliminar = new Button();
            btnActualizar = new Button();
            btnGuardar = new Button();
            txtDescripcion = new TextBox();
            label5 = new Label();
            txtNombre = new TextBox();
            dgvMaterias = new DataGridView();
            label1 = new Label();
            menuStrip1 = new MenuStrip();
            inicioToolStripMenuItem = new ToolStripMenuItem();
            estudiantesToolStripMenuItem = new ToolStripMenuItem();
            materiasToolStripMenuItem = new ToolStripMenuItem();
            calificacionesToolStripMenuItem = new ToolStripMenuItem();
            label4 = new Label();
            btnExportar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvMaterias).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.Red;
            btnEliminar.ForeColor = SystemColors.ButtonFace;
            btnEliminar.Location = new Point(345, 424);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(75, 34);
            btnEliminar.TabIndex = 34;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = false;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnActualizar
            // 
            btnActualizar.BackColor = SystemColors.Highlight;
            btnActualizar.ForeColor = SystemColors.ButtonFace;
            btnActualizar.Location = new Point(194, 424);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(75, 34);
            btnActualizar.TabIndex = 33;
            btnActualizar.Text = "Actualizar";
            btnActualizar.UseVisualStyleBackColor = false;
            btnActualizar.Click += btnActualizar_Click;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(0, 192, 0);
            btnGuardar.ForeColor = SystemColors.ButtonFace;
            btnGuardar.Location = new Point(58, 424);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 34);
            btnGuardar.TabIndex = 32;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // txtDescripcion
            // 
            txtDescripcion.Font = new Font("Segoe UI", 11.25F);
            txtDescripcion.Location = new Point(58, 252);
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new Size(142, 27);
            txtDescripcion.TabIndex = 30;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F);
            label5.Location = new Point(58, 229);
            label5.Name = "label5";
            label5.Size = new Size(85, 20);
            label5.TabIndex = 29;
            label5.Text = "Descriccion";
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Segoe UI", 11.25F);
            txtNombre.Location = new Point(58, 163);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(142, 27);
            txtNombre.TabIndex = 27;
            // 
            // dgvMaterias
            // 
            dgvMaterias.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMaterias.Location = new Point(258, 163);
            dgvMaterias.Name = "dgvMaterias";
            dgvMaterias.Size = new Size(363, 198);
            dgvMaterias.TabIndex = 26;
            dgvMaterias.CellContentClick += dgvMaterias_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F);
            label1.Location = new Point(58, 137);
            label1.Name = "label1";
            label1.Size = new Size(60, 20);
            label1.TabIndex = 24;
            label1.Text = "Materia";
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.HotTrack;
            menuStrip1.Items.AddRange(new ToolStripItem[] { inicioToolStripMenuItem, estudiantesToolStripMenuItem, materiasToolStripMenuItem, calificacionesToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 33);
            menuStrip1.TabIndex = 36;
            menuStrip1.Text = "menuStrip1";
            // 
            // inicioToolStripMenuItem
            // 
            inicioToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inicioToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            inicioToolStripMenuItem.Size = new Size(73, 29);
            inicioToolStripMenuItem.Text = "Inicio";
            inicioToolStripMenuItem.Click += inicioToolStripMenuItem_Click;
            // 
            // estudiantesToolStripMenuItem
            // 
            estudiantesToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            estudiantesToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            estudiantesToolStripMenuItem.Name = "estudiantesToolStripMenuItem";
            estudiantesToolStripMenuItem.Size = new Size(125, 29);
            estudiantesToolStripMenuItem.Text = "Estudiantes";
            estudiantesToolStripMenuItem.Click += estudiantesToolStripMenuItem_Click;
            // 
            // materiasToolStripMenuItem
            // 
            materiasToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            materiasToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            materiasToolStripMenuItem.Name = "materiasToolStripMenuItem";
            materiasToolStripMenuItem.Size = new Size(100, 29);
            materiasToolStripMenuItem.Text = "Materias";
            materiasToolStripMenuItem.Click += materiasToolStripMenuItem_Click;
            // 
            // calificacionesToolStripMenuItem
            // 
            calificacionesToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            calificacionesToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            calificacionesToolStripMenuItem.Name = "calificacionesToolStripMenuItem";
            calificacionesToolStripMenuItem.Size = new Size(143, 29);
            calificacionesToolStripMenuItem.Text = "$safeprojectname$";
            calificacionesToolStripMenuItem.Click += calificacionesToolStripMenuItem_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.Control;
            label4.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(58, 60);
            label4.Name = "label4";
            label4.Size = new Size(180, 32);
            label4.TabIndex = 0;
            label4.Text = "Crear materias";
            label4.Click += label4_Click;
            // 
            // btnExportar
            // 
            btnExportar.BackColor = Color.DarkOrange;
            btnExportar.ForeColor = SystemColors.ButtonFace;
            btnExportar.Location = new Point(461, 424);
            btnExportar.Name = "btnExportar";
            btnExportar.Size = new Size(79, 34);
            btnExportar.TabIndex = 42;
            btnExportar.Text = "Exportar";
            btnExportar.UseVisualStyleBackColor = false;
            btnExportar.Click += btnExportar_Click;
            // 
            // FrmMaterias
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 498);
            Controls.Add(btnExportar);
            Controls.Add(label4);
            Controls.Add(btnEliminar);
            Controls.Add(btnActualizar);
            Controls.Add(btnGuardar);
            Controls.Add(txtDescripcion);
            Controls.Add(label5);
            Controls.Add(txtNombre);
            Controls.Add(dgvMaterias);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "FrmMaterias";
            Load += FrmMaterias_Load;
            ((System.ComponentModel.ISupportInitialize)dgvMaterias).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnEliminar;
        private Button btnActualizar;
        private Button btnGuardar;
        private TextBox txtDescripcion;
        private Label label5;
        private TextBox txtNombre;
        private DataGridView dgvMaterias;
        private Label label1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem inicioToolStripMenuItem;
        private Label label4;
        private ToolStripMenuItem estudiantesToolStripMenuItem;
        private ToolStripMenuItem materiasToolStripMenuItem;
        private ToolStripMenuItem calificacionesToolStripMenuItem;
        private Button btnExportar;
    }
}