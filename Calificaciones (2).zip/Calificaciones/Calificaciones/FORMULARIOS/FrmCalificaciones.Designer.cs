﻿namespace $safeprojectname$.Forms
{
    partial class FrmCalificaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEliminar = new Button();
            button2 = new Button();
            btnAgregar = new Button();
            cmbEstudiante = new ComboBox();
            cmbMateria = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            Numero1 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtCal1 = new TextBox();
            txtExamen = new TextBox();
            txtCal3 = new TextBox();
            txtCal2 = new TextBox();
            txtCal4 = new TextBox();
            label3 = new Label();
            menuStrip1 = new MenuStrip();
            inicioToolStripMenuItem = new ToolStripMenuItem();
            estudiantesToolStripMenuItem = new ToolStripMenuItem();
            calificacionesToolStripMenuItem = new ToolStripMenuItem();
            calificacionesToolStripMenuItem1 = new ToolStripMenuItem();
            dgvCalificaciones = new DataGridView();
            btnExportar = new Button();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCalificaciones).BeginInit();
            SuspendLayout();
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.Red;
            btnEliminar.Location = new Point(397, 572);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(86, 39);
            btnEliminar.TabIndex = 15;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = false;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.Highlight;
            button2.Location = new Point(513, 572);
            button2.Name = "button2";
            button2.Size = new Size(80, 39);
            button2.TabIndex = 14;
            button2.Text = "Actualizar";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.FromArgb(0, 192, 0);
            btnAgregar.Location = new Point(288, 572);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(75, 39);
            btnAgregar.TabIndex = 13;
            btnAgregar.Text = "Guardar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // cmbEstudiante
            // 
            cmbEstudiante.Font = new Font("Segoe UI", 11.25F);
            cmbEstudiante.FormattingEnabled = true;
            cmbEstudiante.Items.AddRange(new object[] { "\"\"" });
            cmbEstudiante.Location = new Point(66, 179);
            cmbEstudiante.Name = "cmbEstudiante";
            cmbEstudiante.Size = new Size(181, 28);
            cmbEstudiante.TabIndex = 19;
            // 
            // cmbMateria
            // 
            cmbMateria.Font = new Font("Segoe UI", 11.25F);
            cmbMateria.FormattingEnabled = true;
            cmbMateria.Items.AddRange(new object[] { "\"\"" });
            cmbMateria.Location = new Point(66, 249);
            cmbMateria.Name = "cmbMateria";
            cmbMateria.Size = new Size(181, 28);
            cmbMateria.TabIndex = 20;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F);
            label1.Location = new Point(66, 151);
            label1.Name = "label1";
            label1.Size = new Size(78, 20);
            label1.TabIndex = 21;
            label1.Text = "Estudiante";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F);
            label2.Location = new Point(66, 231);
            label2.Name = "label2";
            label2.Size = new Size(60, 20);
            label2.TabIndex = 22;
            label2.Text = "Materia";
            // 
            // Numero1
            // 
            Numero1.AutoSize = true;
            Numero1.Font = new Font("Segoe UI", 11.25F);
            Numero1.Location = new Point(66, 307);
            Numero1.Name = "Numero1";
            Numero1.Size = new Size(71, 20);
            Numero1.TabIndex = 28;
            Numero1.Text = "Numero1";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F);
            label4.Location = new Point(66, 384);
            label4.Name = "label4";
            label4.Size = new Size(71, 20);
            label4.TabIndex = 29;
            label4.Text = "Numero2";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F);
            label5.Location = new Point(66, 468);
            label5.Name = "label5";
            label5.Size = new Size(71, 20);
            label5.TabIndex = 30;
            label5.Text = "Numero3";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11.25F);
            label6.Location = new Point(66, 561);
            label6.Name = "label6";
            label6.Size = new Size(71, 20);
            label6.TabIndex = 31;
            label6.Text = "Numero4";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11.25F);
            label7.Location = new Point(66, 645);
            label7.Name = "label7";
            label7.Size = new Size(56, 20);
            label7.TabIndex = 32;
            label7.Text = "Exanen";
            // 
            // txtCal1
            // 
            txtCal1.Font = new Font("Segoe UI", 11.25F);
            txtCal1.Location = new Point(66, 325);
            txtCal1.Name = "txtCal1";
            txtCal1.Size = new Size(181, 27);
            txtCal1.TabIndex = 33;
            // 
            // txtExamen
            // 
            txtExamen.Font = new Font("Segoe UI", 11.25F);
            txtExamen.Location = new Point(66, 665);
            txtExamen.Name = "txtExamen";
            txtExamen.Size = new Size(181, 27);
            txtExamen.TabIndex = 34;
            // 
            // txtCal3
            // 
            txtCal3.Font = new Font("Segoe UI", 11.25F);
            txtCal3.Location = new Point(66, 491);
            txtCal3.Name = "txtCal3";
            txtCal3.Size = new Size(181, 27);
            txtCal3.TabIndex = 35;
            // 
            // txtCal2
            // 
            txtCal2.Font = new Font("Segoe UI", 11.25F);
            txtCal2.Location = new Point(66, 407);
            txtCal2.Name = "txtCal2";
            txtCal2.Size = new Size(181, 27);
            txtCal2.TabIndex = 36;
            // 
            // txtCal4
            // 
            txtCal4.Font = new Font("Segoe UI", 11.25F);
            txtCal4.Location = new Point(66, 584);
            txtCal4.Name = "txtCal4";
            txtCal4.Size = new Size(181, 27);
            txtCal4.TabIndex = 37;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(66, 101);
            label3.Name = "label3";
            label3.Size = new Size(235, 32);
            label3.TabIndex = 0;
            label3.Text = "Crear calificaciones";
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.HotTrack;
            menuStrip1.Items.AddRange(new ToolStripItem[] { inicioToolStripMenuItem, estudiantesToolStripMenuItem, calificacionesToolStripMenuItem, calificacionesToolStripMenuItem1 });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1451, 33);
            menuStrip1.TabIndex = 39;
            menuStrip1.Text = "menuStrip1";
            // 
            // inicioToolStripMenuItem
            // 
            inicioToolStripMenuItem.BackColor = SystemColors.HotTrack;
            inicioToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inicioToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            inicioToolStripMenuItem.Size = new Size(73, 29);
            inicioToolStripMenuItem.Text = "Inicio";
            inicioToolStripMenuItem.Click += inicioToolStripMenuItem_Click;
            // 
            // estudiantesToolStripMenuItem
            // 
            estudiantesToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            estudiantesToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            estudiantesToolStripMenuItem.Name = "estudiantesToolStripMenuItem";
            estudiantesToolStripMenuItem.Size = new Size(125, 29);
            estudiantesToolStripMenuItem.Text = "Estudiantes";
            estudiantesToolStripMenuItem.Click += estudiantesToolStripMenuItem_Click_1;
            // 
            // calificacionesToolStripMenuItem
            // 
            calificacionesToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            calificacionesToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            calificacionesToolStripMenuItem.Name = "calificacionesToolStripMenuItem";
            calificacionesToolStripMenuItem.Size = new Size(100, 29);
            calificacionesToolStripMenuItem.Text = "Materias";
            calificacionesToolStripMenuItem.Click += calificacionesToolStripMenuItem_Click;
            // 
            // calificacionesToolStripMenuItem1
            // 
            calificacionesToolStripMenuItem1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            calificacionesToolStripMenuItem1.ForeColor = SystemColors.ButtonFace;
            calificacionesToolStripMenuItem1.Name = "calificacionesToolStripMenuItem1";
            calificacionesToolStripMenuItem1.Size = new Size(143, 29);
            calificacionesToolStripMenuItem1.Text = "$safeprojectname$";
            calificacionesToolStripMenuItem1.Click += calificacionesToolStripMenuItem1_Click;
            // 
            // dgvCalificaciones
            // 
            dgvCalificaciones.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCalificaciones.Location = new Point(288, 179);
            dgvCalificaciones.Name = "dgvCalificaciones";
            dgvCalificaciones.Size = new Size(1136, 339);
            dgvCalificaciones.TabIndex = 40;
            dgvCalificaciones.CellClick += dataGridView1_CellContentClickdataGridView1_CellClick;
            dgvCalificaciones.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // btnExportar
            // 
            btnExportar.BackColor = Color.DarkOrange;
            btnExportar.ForeColor = SystemColors.ButtonFace;
            btnExportar.Location = new Point(637, 572);
            btnExportar.Name = "btnExportar";
            btnExportar.Size = new Size(91, 39);
            btnExportar.TabIndex = 41;
            btnExportar.Text = "Exportar";
            btnExportar.UseVisualStyleBackColor = false;
            btnExportar.Click += btnExportar_Click_1;
            // 
            // FrmCalificaciones
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1451, 863);
            Controls.Add(btnExportar);
            Controls.Add(dgvCalificaciones);
            Controls.Add(label3);
            Controls.Add(txtCal4);
            Controls.Add(txtCal2);
            Controls.Add(txtCal3);
            Controls.Add(txtExamen);
            Controls.Add(txtCal1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(Numero1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cmbMateria);
            Controls.Add(cmbEstudiante);
            Controls.Add(btnEliminar);
            Controls.Add(button2);
            Controls.Add(btnAgregar);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MainMenuStrip = menuStrip1;
            Name = "FrmCalificaciones";
            SizeGripStyle = SizeGripStyle.Hide;
            Load += FrmCalificaciones_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCalificaciones).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnEliminar;
        private Button button2;
        private Button btnAgregar;
        private ComboBox cmbEstudiante;
        private ComboBox cmbMateria;
        private Label label1;
        private Label label2;
        private Label Numero1;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtCal1;
        private TextBox txtExamen;
        private TextBox txtCal3;
        private TextBox txtCal2;
        private TextBox txtCal4;
        private Label label3;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem inicioToolStripMenuItem;
        private ToolStripMenuItem estudiantesToolStripMenuItem;
        private ToolStripMenuItem calificacionesToolStripMenuItem;
        private ToolStripMenuItem calificacionesToolStripMenuItem1;
        private DataGridView dgvCalificaciones;
        private Button btnExportar;
    }
}