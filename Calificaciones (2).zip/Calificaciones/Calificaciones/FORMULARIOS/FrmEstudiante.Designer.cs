﻿namespace $safeprojectname$.Formularios
{
    partial class FrmEstudiante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            dgvEstudiantes = new DataGridView();
            txtNombre = new TextBox();
            txtMatricula = new TextBox();
            label5 = new Label();
            txtCorreo = new TextBox();
            label4 = new Label();
            btnEliminar = new Button();
            btnActualizar = new Button();
            btnGuardar = new Button();
            menuStrip1 = new MenuStrip();
            inicioToolStripMenuItem = new ToolStripMenuItem();
            estudiantesToolStripMenuItem = new ToolStripMenuItem();
            materiasToolStripMenuItem = new ToolStripMenuItem();
            calificacionesToolStripMenuItem = new ToolStripMenuItem();
            btnExportar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvEstudiantes).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F);
            label1.Location = new Point(44, 192);
            label1.Name = "label1";
            label1.Size = new Size(64, 20);
            label1.TabIndex = 0;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F);
            label2.Location = new Point(44, 388);
            label2.Name = "label2";
            label2.Size = new Size(71, 20);
            label2.TabIndex = 2;
            label2.Text = "Matricula";
            // 
            // dgvEstudiantes
            // 
            dgvEstudiantes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEstudiantes.Location = new Point(256, 232);
            dgvEstudiantes.Name = "dgvEstudiantes";
            dgvEstudiantes.Size = new Size(555, 206);
            dgvEstudiantes.TabIndex = 4;
            dgvEstudiantes.CellContentClick += dgvEstudiante_CellContentClick;
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Segoe UI", 11.25F);
            txtNombre.Location = new Point(44, 232);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(142, 27);
            txtNombre.TabIndex = 8;
            // 
            // txtMatricula
            // 
            txtMatricula.Font = new Font("Segoe UI", 11.25F);
            txtMatricula.Location = new Point(44, 411);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(142, 27);
            txtMatricula.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F);
            label5.Location = new Point(44, 298);
            label5.Name = "label5";
            label5.Size = new Size(54, 20);
            label5.TabIndex = 14;
            label5.Text = "Correo";
            // 
            // txtCorreo
            // 
            txtCorreo.Font = new Font("Segoe UI", 11.25F);
            txtCorreo.Location = new Point(44, 321);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(142, 27);
            txtCorreo.TabIndex = 16;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(44, 110);
            label4.Name = "label4";
            label4.Size = new Size(213, 32);
            label4.TabIndex = 0;
            label4.Text = "Crear estudiantes";
            label4.Click += label4_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.Red;
            btnEliminar.ForeColor = SystemColors.ButtonFace;
            btnEliminar.Location = new Point(256, 509);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(75, 34);
            btnEliminar.TabIndex = 22;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = false;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnActualizar
            // 
            btnActualizar.BackColor = SystemColors.Highlight;
            btnActualizar.ForeColor = SystemColors.ButtonFace;
            btnActualizar.Location = new Point(139, 509);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(75, 34);
            btnActualizar.TabIndex = 21;
            btnActualizar.Text = "Actualizar";
            btnActualizar.UseVisualStyleBackColor = false;
            btnActualizar.Click += btnActualizar_Click_1;
            // 
            // btnGuardar
            // 
            btnGuardar.BackColor = Color.FromArgb(0, 192, 0);
            btnGuardar.ForeColor = SystemColors.ButtonFace;
            btnGuardar.Location = new Point(26, 509);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 34);
            btnGuardar.TabIndex = 20;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = false;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.HotTrack;
            menuStrip1.Items.AddRange(new ToolStripItem[] { inicioToolStripMenuItem, estudiantesToolStripMenuItem, materiasToolStripMenuItem, calificacionesToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(841, 33);
            menuStrip1.TabIndex = 24;
            menuStrip1.Text = "menuStrip1";
            // 
            // inicioToolStripMenuItem
            // 
            inicioToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            inicioToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            inicioToolStripMenuItem.Size = new Size(73, 29);
            inicioToolStripMenuItem.Text = "Inicio";
            inicioToolStripMenuItem.Click += inicioToolStripMenuItem_Click;
            // 
            // estudiantesToolStripMenuItem
            // 
            estudiantesToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            estudiantesToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            estudiantesToolStripMenuItem.Name = "estudiantesToolStripMenuItem";
            estudiantesToolStripMenuItem.Size = new Size(125, 29);
            estudiantesToolStripMenuItem.Text = "Estudiantes";
            // 
            // materiasToolStripMenuItem
            // 
            materiasToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            materiasToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            materiasToolStripMenuItem.Name = "materiasToolStripMenuItem";
            materiasToolStripMenuItem.Size = new Size(100, 29);
            materiasToolStripMenuItem.Text = "Materias";
            materiasToolStripMenuItem.Click += materiasToolStripMenuItem_Click;
            // 
            // calificacionesToolStripMenuItem
            // 
            calificacionesToolStripMenuItem.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            calificacionesToolStripMenuItem.ForeColor = SystemColors.ButtonFace;
            calificacionesToolStripMenuItem.Name = "calificacionesToolStripMenuItem";
            calificacionesToolStripMenuItem.Size = new Size(143, 29);
            calificacionesToolStripMenuItem.Text = "$safeprojectname$";
            calificacionesToolStripMenuItem.Click += calificacionesToolStripMenuItem_Click;
            // 
            // btnExportar
            // 
            btnExportar.BackColor = Color.DarkOrange;
            btnExportar.ForeColor = SystemColors.ButtonFace;
            btnExportar.Location = new Point(354, 509);
            btnExportar.Name = "btnExportar";
            btnExportar.Size = new Size(80, 34);
            btnExportar.TabIndex = 42;
            btnExportar.Text = "Exportar";
            btnExportar.UseVisualStyleBackColor = false;
            btnExportar.Click += btnExportar_Click;
            // 
            // FrmEstudiante
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(841, 635);
            Controls.Add(btnExportar);
            Controls.Add(label4);
            Controls.Add(btnEliminar);
            Controls.Add(btnActualizar);
            Controls.Add(btnGuardar);
            Controls.Add(txtCorreo);
            Controls.Add(label5);
            Controls.Add(txtMatricula);
            Controls.Add(txtNombre);
            Controls.Add(dgvEstudiantes);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "FrmEstudiante";
            Load += FrmEstudiante_Load;
            ((System.ComponentModel.ISupportInitialize)dgvEstudiantes).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private DataGridView dgvEstudiantes;
        private TextBox txtNombre;
        private TextBox txtMatricula;
        private Label label4;
        private Label label5;
        private TextBox textBox1;
        private TextBox txtCorreo;
        private Button btnEliminar;
        private Button btnActualizar;
        private Button btnGuardar;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem inicioToolStripMenuItem;
        private ToolStripMenuItem estudiantesToolStripMenuItem;
        private ToolStripMenuItem materiasToolStripMenuItem;
        private ToolStripMenuItem calificacionesToolStripMenuItem;
        private Button btnExportar;
    }
}