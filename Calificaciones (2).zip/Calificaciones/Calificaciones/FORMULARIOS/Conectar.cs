﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.Data.SqlClient;

namespace $safeprojectname$.Formularios
{
    public partial class Conectar : Form
    {
        public Conectar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            string cadenaConexion = "Data Source=RONNY\\SQLEXPRESS;Initial Catalog=dbCalificaciones;Integrated Security=True;TrustServerCertificate=True;";
            using (SqlConnection conexion = new SqlConnection(cadenaConexion))
            {
                try
                {
                    conexion.Open();
                    MessageBox.Show("Conexión exitosa a la base de datos.");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error al conectar a la base de datos: " + ex.Message);
                }
            }


        }
    }
}
