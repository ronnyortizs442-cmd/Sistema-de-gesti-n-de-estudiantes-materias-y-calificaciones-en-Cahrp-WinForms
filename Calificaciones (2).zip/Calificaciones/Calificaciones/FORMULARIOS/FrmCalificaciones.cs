﻿using $safeprojectname$.Datos;
using $safeprojectname$.Formularios;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Data.SqlClient;
using $safeprojectname$.Entidad;

namespace $safeprojectname$.Forms
{
    public partial class FrmCalificaciones : Form
    {
        EstudianteDAL estudianteDAL = new EstudianteDAL();
        MateriaDAL materiaDAL = new MateriaDAL();
        CalificacionDAL calificacionDAL = new CalificacionDAL();
        private int calificacionSeleccionadaID;
        Calificacion calificacion = new Calificacion();

        public FrmCalificaciones()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string error = "";

            if (cmbEstudiante.SelectedIndex == -1)
                error += "Debe seleccionar un estudiante.\n";

            if (cmbMateria.SelectedIndex == -1)
                error += "Debe seleccionar una materia.\n";

            if (string.IsNullOrWhiteSpace(txtCal1.Text) ||
                string.IsNullOrWhiteSpace(txtCal2.Text) ||
                string.IsNullOrWhiteSpace(txtCal3.Text) ||
                string.IsNullOrWhiteSpace(txtCal4.Text) ||
                string.IsNullOrWhiteSpace(txtExamen.Text))
                error += "Todos los campos de calificaciones deben contener datos.\n";

            if (error != "")
            {
                MessageBox.Show(error);
                return;
            }

            if (!decimal.TryParse(txtCal1.Text, out decimal cal1) ||
                !decimal.TryParse(txtCal2.Text, out decimal cal2) ||
                !decimal.TryParse(txtCal3.Text, out decimal cal3) ||
                !decimal.TryParse(txtCal4.Text, out decimal cal4) ||
                !decimal.TryParse(txtExamen.Text, out decimal examen))
            {
                MessageBox.Show("Todos los campos deben contener valores numéricos.");
                return;
            }

            if (!ValidarRango(cal1) || !ValidarRango(cal2) || !ValidarRango(cal3) ||
                !ValidarRango(cal4) || !ValidarRango(examen))
            {
                MessageBox.Show("Las calificaciones deben estar entre 0 y 100.");
                return;
            }

            try
            {
                int estudianteID = (int)cmbEstudiante.SelectedValue;
                int materiaID = (int)cmbMateria.SelectedValue;

                calificacionDAL.Insertar(estudianteID, materiaID, cal1, cal2, cal3, cal4, examen);

                MessageBox.Show("Calificación guardada correctamente.");
                dgvCalificaciones.DataSource = calificacionDAL.Listar();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la calificación: " + ex.Message);
            }
        }


        private void FrmCalificaciones_Load(object sender, EventArgs e)
        {
            CargarGrid();

            cmbEstudiante.DataSource = estudianteDAL.Listar();
            cmbEstudiante.DisplayMember = "Nombre";
            cmbEstudiante.ValueMember = "EstudianteID";
            cmbEstudiante.SelectedIndex = -1;
            cmbEstudiante.Text = "Seleccione un Estudiante";

            cmbMateria.DataSource = materiaDAL.Listar();
            cmbMateria.DisplayMember = "Nombre";
            cmbMateria.ValueMember = "MateriaID";
            cmbMateria.SelectedIndex = -1;
            cmbMateria.Text = "Seleccione una Materia";

            dgvCalificaciones.ClearSelection();
            dgvCalificaciones.CurrentCell = null;
        }

        private void CargarGrid()
        {
            dgvCalificaciones.DataSource = calificacionDAL.Listar();
        }


        private bool ValidarRango(decimal valor)
        {
            return valor >= 0 && valor <= 100;
        }

        private void LimpiarCampos()
        {
            txtCal1.Clear();
            txtCal2.Clear();
            txtCal3.Clear();
            txtCal4.Clear();
            txtExamen.Clear();

            cmbEstudiante.SelectedIndex = -1;
            cmbMateria.SelectedIndex = -1;

            txtCal1.Focus();
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgvCalificaciones_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow fila = dgvCalificaciones.Rows[e.RowIndex];

            calificacionSeleccionadaID = Convert.ToInt32(fila.Cells["CalificacionID"].Value);

            cmbEstudiante.Text = fila.Cells["Estudiante"].Value.ToString();
            cmbMateria.Text = fila.Cells["Materia"].Value.ToString();

            txtCal1.Text = fila.Cells["Cal1"].Value.ToString();
            txtCal2.Text = fila.Cells["Cal2"].Value.ToString();
            txtCal3.Text = fila.Cells["Cal3"].Value.ToString();
            txtCal4.Text = fila.Cells["Cal4"].Value.ToString();
            txtExamen.Text = fila.Cells["Examen"].Value.ToString();
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {

        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMenu frmMenu = new FrmMenu();
            frmMenu.Show();
            this.Hide();
        }

        private void estudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmEstudiante frmEstudiante = new FrmEstudiante();
            frmEstudiante.Show();
            this.Hide();
        }

        private void materiasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMaterias frmMaterias = new FrmMaterias();
            frmMaterias.Show();
            this.Hide();
        }

        private void calificacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCalificaciones frmCalificaciones = new FrmCalificaciones();
            frmCalificaciones.Show();
            this.Hide();
        }

        private void estudiantesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FrmEstudiante frmEstudiante = new FrmEstudiante();
            frmEstudiante.Show();
            this.Hide();
        }

        private void calificacionesToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvCalificaciones.CurrentRow == null)
            {
                MessageBox.Show("Seleccione una calificación.");
                return;
            }

            if (MessageBox.Show("¿Seguro que desea eliminar esta calificación?",
                                "Confirmación",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Warning) == DialogResult.No)
            {
                return;
            }

            int CalificacionID = Convert.ToInt32(
                dgvCalificaciones.CurrentRow.Cells["CalificacionID"].Value);

            try
            {
                CalificacionDAL calificacionDAL = new CalificacionDAL();
                calificacionDAL.Eliminar(CalificacionID);

                MessageBox.Show("Calificación eliminada correctamente.");

                dgvCalificaciones.DataSource = calificacionDAL.Listar();

                dgvCalificaciones.ClearSelection();
                dgvCalificaciones.CurrentCell = null;
            }
            catch (SqlException ex)
            {
                if (ex.Number == 547)
                {
                    MessageBox.Show("No puedes eliminar esta calificación porque está asociada a otros datos.",
                                    "Operación no permitida", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow fila = dgvCalificaciones.Rows[e.RowIndex];

            calificacionSeleccionadaID = Convert.ToInt32(fila.Cells["CalificacionID"].Value);

            cmbEstudiante.Text = fila.Cells["Estudiante"].Value.ToString();
            cmbMateria.Text = fila.Cells["Materia"].Value.ToString();

            txtCal1.Text = fila.Cells["Cal1"].Value.ToString();
            txtCal2.Text = fila.Cells["Cal2"].Value.ToString();
            txtCal3.Text = fila.Cells["Cal3"].Value.ToString();
            txtCal4.Text = fila.Cells["Cal4"].Value.ToString();
            txtExamen.Text = fila.Cells["Examen"].Value.ToString();
        }

        private void dataGridView1_CellContentClickdataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnExportar_Click_1(object sender, EventArgs e)
        {
            if (dgvCalificaciones.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.");
                return;
            }

            SaveFileDialog guardar = new SaveFileDialog();
            guardar.Filter = "Archivo PDF (*.pdf)|*.pdf";
            guardar.FileName = "$safeprojectname$.pdf";

            if (guardar.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    iTextSharp.text.Document pdf = new iTextSharp.text.Document(PageSize.A4, 20, 20, 20, 20);
                    PdfWriter.GetInstance(pdf, new FileStream(guardar.FileName, FileMode.Create));

                    pdf.Open();

                    Paragraph titulo = new Paragraph("REPORTE DE CALIFICACIONES\n\n",
                        FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18));
                    titulo.Alignment = Element.ALIGN_CENTER;
                    pdf.Add(titulo);

                    PdfPTable tabla = new PdfPTable(dgvCalificaciones.Columns.Count);
                    tabla.WidthPercentage = 100;

                    foreach (DataGridViewColumn columna in dgvCalificaciones.Columns)
                    {
                        PdfPCell celda = new PdfPCell(new Phrase(columna.HeaderText));
                        celda.BackgroundColor = BaseColor.LIGHT_GRAY;
                        tabla.AddCell(celda);
                    }

                    foreach (DataGridViewRow fila in dgvCalificaciones.Rows)
                    {
                        if (!fila.IsNewRow)
                        {
                            foreach (DataGridViewCell celda in fila.Cells)
                            {
                                tabla.AddCell(celda.Value?.ToString() ?? "");
                            }
                        }
                    }

                    pdf.Add(tabla);
                    pdf.Close();

                    MessageBox.Show("PDF exportado correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al exportar: " + ex.Message);
                }
            }
        }
        
    }
}
