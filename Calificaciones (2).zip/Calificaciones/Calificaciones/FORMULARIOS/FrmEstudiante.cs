﻿using $safeprojectname$.Datos;
using $safeprojectname$.Entidad;
using $safeprojectname$.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Data.SqlClient;
using System.Drawing.Text;
using System.Text.RegularExpressions;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace $safeprojectname$.Formularios
{
    public partial class FrmEstudiante : Form
    {
        Estudiante estudiante = new Estudiante();
        EstudianteDAL estudianteDAL = new EstudianteDAL();
        public FrmEstudiante()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmEstudiante_Load(object sender, EventArgs e)
        {
            dgvEstudiantes.DataSource = estudianteDAL.Listar();
            dgvEstudiantes.ClearSelection();
            dgvEstudiantes.CurrentCell = null;

        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtCorreo.Clear();
            txtMatricula.Clear();
        }



        private void dgvEstudiante_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void cbEstudiante_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {

        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {



        }

        private void txtEliminar_Click(object sender, EventArgs e)
        {


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private bool EsCorreoValido(string correo)
        {
            return Regex.IsMatch(correo, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        private bool EsMatriculaValida(string matricula)
        {
            return Regex.IsMatch(matricula, @"^SD-\d{4}-\d{5}$");
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string Nombre = txtNombre.Text.Trim();
            string Correo = txtCorreo.Text.Trim();
            string Matricula = txtMatricula.Text.Trim();

            if (Nombre == "" || Correo == "" || Matricula == "")
            {
                MessageBox.Show("Debe llenar los espacios vacíos.");
                return;
            }

            if (Nombre.Any(char.IsDigit))
            {
                MessageBox.Show("El nombre no puede contener números.");
                return;
            }

            if (!EsCorreoValido(Correo))
            {
                MessageBox.Show("Formato de correo no válido. Ejemplo: nombre@mail.com");
                return;
            }

            if (!EsMatriculaValida(Matricula))
            {
                MessageBox.Show("Formato de matrícula incorrecto. Ejemplo: SD-2022-04013");
                return;
            }

            estudianteDAL.Guardar(Nombre, Correo, Matricula);
            MessageBox.Show("Estudiante guardado correctamente");

            dgvEstudiantes.DataSource = estudianteDAL.Listar();
            LimpiarCampos();
        }

        private void btnActualizar_Click_1(object sender, EventArgs e)
        {
            if (dgvEstudiantes.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un registro en el DataGridView.");
                return;
            }

            int Id = Convert.ToInt32(dgvEstudiantes.CurrentRow.Cells["EstudianteID"].Value);

            string Nombre = txtNombre.Text.Trim();
            string Matricula = txtMatricula.Text.Trim();
            string Correo = txtCorreo.Text.Trim();

            if (string.IsNullOrWhiteSpace(Nombre) ||
                string.IsNullOrWhiteSpace(Matricula) ||
                string.IsNullOrWhiteSpace(Correo))
            {
                MessageBox.Show("Complete todos los campos.");
                return;
            }

            if (Nombre.Any(char.IsDigit))
            {
                MessageBox.Show("El nombre no puede contener números.");
                return;
            }

            if (!EsCorreoValido(Correo))
            {
                MessageBox.Show("Formato de correo no válido.");
                return;
            }

            if (!EsMatriculaValida(Matricula))
            {
                MessageBox.Show("Formato de matrícula incorrecta debe de ser Ejemplo: SD-2022-04013");
                return;
            }

            EstudianteDAL estudianteDAL = new EstudianteDAL();
            estudianteDAL.Actualizar(Id, Nombre, Matricula, Correo);

            MessageBox.Show("Estudiante actualizado correctamente.");
            dgvEstudiantes.DataSource = estudianteDAL.Listar();
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvEstudiantes.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un estudiante.");
                return;
            }

            int EstudianteID = Convert.ToInt32(
                dgvEstudiantes.CurrentRow.Cells["EstudianteID"].Value);

            try
            {
                EstudianteDAL estudianteDAL = new EstudianteDAL();
                estudianteDAL.Eliminar(EstudianteID);

                MessageBox.Show("Estudiante eliminado correctamente.");
                dgvEstudiantes.DataSource = estudianteDAL.Listar();
            }
            catch (SqlException ex)
            {
                if (ex.Number == 547)
                {
                    MessageBox.Show("No puedes eliminar este estudiante porque tiene calificaciones registradas.",
                                    "Operación no permitida", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMenu frmMenu = new FrmMenu();
            frmMenu.Show();
            this.Hide();

        }

        private void estudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmEstudiante frmEstudiante = new FrmEstudiante();
            frmEstudiante.Show();
            this.Hide();
        }

        private void materiasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMaterias frmMaterias = new FrmMaterias();
            frmMaterias.Show();
            this.Hide();
        }

        private void calificacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCalificaciones frmCalificaciones = new FrmCalificaciones();
            frmCalificaciones.Show();
            this.Hide();

        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            if (dgvEstudiantes.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.");
                return;
            }

            SaveFileDialog guardar = new SaveFileDialog();
            guardar.Filter = "Archivo PDF (*.pdf)|*.pdf";
            guardar.FileName = "Estudiantes.pdf";

            if (guardar.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    iTextSharp.text.Document pdf = new iTextSharp.text.Document(PageSize.A4, 20, 20, 20, 20);
                    PdfWriter.GetInstance(pdf, new FileStream(guardar.FileName, FileMode.Create));

                    pdf.Open();

                    Paragraph titulo = new Paragraph("REPORTE DE Estudiantes\n\n",
                        FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18));
                    titulo.Alignment = Element.ALIGN_CENTER;
                    pdf.Add(titulo);

                    PdfPTable tabla = new PdfPTable(dgvEstudiantes.Columns.Count);
                    tabla.WidthPercentage = 100;

                    foreach (DataGridViewColumn columna in dgvEstudiantes.Columns)
                    {
                        PdfPCell celda = new PdfPCell(new Phrase(columna.HeaderText));
                        celda.BackgroundColor = BaseColor.LIGHT_GRAY;
                        tabla.AddCell(celda);
                    }

                    foreach (DataGridViewRow fila in dgvEstudiantes.Rows)
                    {
                        if (!fila.IsNewRow)
                        {
                            foreach (DataGridViewCell celda in fila.Cells)
                            {
                                tabla.AddCell(celda.Value?.ToString() ?? "");
                            }
                        }
                    }

                    pdf.Add(tabla);
                    pdf.Close();

                    MessageBox.Show("PDF exportado correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al exportar: " + ex.Message);
                }
            }
         }
    }
}