﻿using $safeprojectname$.Datos;
using $safeprojectname$.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using $safeprojectname$.Entidad;

namespace $safeprojectname$.Formularios
{
    public partial class FrmMaterias : Form
    {
        MateriaDAL materiaDAL = new MateriaDAL();


        public FrmMaterias()
        {
            InitializeComponent();
        }

        private void FrmMaterias_Load(object sender, EventArgs e)
        {
            CargarMaterias();
            dgvMaterias.ClearSelection();
            dgvMaterias.CurrentCell = null;

        }

        private void CargarMaterias()
        {
            dgvMaterias.DataSource = materiaDAL.Listar();
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtDescripcion.Clear();
        }

        private bool NombreValido(string nombre)
        {
            return !nombre.Any(char.IsDigit);
        }

        private bool MateriaExiste(string nombre)
        {
            DataTable tabla = materiaDAL.Listar();

            foreach (DataRow fila in tabla.Rows)
            {
                string nombreExistente = fila["Nombre"].ToString();

                if (nombreExistente.Equals(nombre, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string descripcion = txtDescripcion.Text.Trim();

            if (MateriaExiste(nombre))
            {
                MessageBox.Show("Esta materia ya existe.");
                return;
            }

            if (nombre == "" || descripcion == "")
            {
                MessageBox.Show("Debe completar todos los campos.");
                return;
            }

            if (!NombreValido(nombre))
            {
                MessageBox.Show("El nombre de la materia no puede contener números.");
                return;
            }

            if (MateriaExiste(nombre))
            {
                MessageBox.Show("Esta materia ya existe. Escriba un nombre diferente.");
                return;
            }

            materiaDAL.Insertar(nombre, descripcion);
            MessageBox.Show("Materia guardada correctamente.");

            CargarMaterias();
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvMaterias.CurrentRow == null)
            {
                MessageBox.Show("Debe seleccionar una materia.");
                return;
            }

            int MateriaID = Convert.ToInt32(
                dgvMaterias.CurrentRow.Cells["MateriaID"].Value);

            try
            {
                MateriaDAL materiaDAL = new MateriaDAL();
                materiaDAL.Eliminar(MateriaID);

                MessageBox.Show("Materia eliminada correctamente.");
                CargarMaterias();
            }
            catch (SqlException ex)
            {
                if (ex.Number == 547)
                {
                    MessageBox.Show(
                        "No puedes eliminar esta materia porque tiene calificaciones registradas.\n" +
                        "Primero elimina las calificaciones asociadas.",
                        "Operación no permitida",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {

            if (dgvMaterias.CurrentRow == null)
            {
                MessageBox.Show("Seleccione una materia para actualizar.");
                return;
            }

            int MateriaID = Convert.ToInt32(dgvMaterias.CurrentRow.Cells["MateriaID"].Value);

            string nombre = txtNombre.Text.Trim();
            string descripcion = txtDescripcion.Text.Trim();

            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(descripcion))
            {
                MessageBox.Show("Complete todos los campos.");
                return;
            }

            if (!NombreValido(nombre))
            {
                MessageBox.Show("El nombre de la materia no puede contener números.");
                return;
            }

            materiaDAL.Actualizar(MateriaID, nombre, descripcion);

            MessageBox.Show("Materia actualizada correctamente.");
            CargarMaterias();
            LimpiarCampos();
        }

        private void dgvMaterias_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtNombre.Text = dgvMaterias.CurrentRow.Cells["Nombre"].Value.ToString();
                txtDescripcion.Text = dgvMaterias.CurrentRow.Cells["Descripcion"].Value.ToString();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMenu frmMenu = new FrmMenu();
            frmMenu.Show();
            this.Hide();
        }

        private void estudiantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmEstudiante frmEstudiante = new FrmEstudiante();
            frmEstudiante.Show();
            this.Hide();
        }

        private void materiasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ;
        }

        private void calificacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCalificaciones frmCalificaciones = new FrmCalificaciones();
            frmCalificaciones.Show();
            this.Hide();
        }

        private void dgvMaterias_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            if (dgvMaterias.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.");
                return;
            }

            SaveFileDialog guardar = new SaveFileDialog();
            guardar.Filter = "Archivo PDF (*.pdf)|*.pdf";
            guardar.FileName = "Materias.pdf";

            if (guardar.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    iTextSharp.text.Document pdf = new iTextSharp.text.Document(PageSize.A4, 20, 20, 20, 20);
                    PdfWriter.GetInstance(pdf, new FileStream(guardar.FileName, FileMode.Create));

                    pdf.Open();

                    Paragraph titulo = new Paragraph("REPORTE DE MATERIAS\n\n",
                        FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18));
                    titulo.Alignment = Element.ALIGN_CENTER;
                    pdf.Add(titulo);

                    PdfPTable tabla = new PdfPTable(dgvMaterias.Columns.Count);
                    tabla.WidthPercentage = 100;

                    foreach (DataGridViewColumn columna in dgvMaterias.Columns)
                    {
                        PdfPCell celda = new PdfPCell(new Phrase(columna.HeaderText));
                        celda.BackgroundColor = BaseColor.LIGHT_GRAY;
                        tabla.AddCell(celda);
                    }

                    foreach (DataGridViewRow fila in dgvMaterias.Rows)
                    {
                        if (!fila.IsNewRow)
                        {
                            foreach (DataGridViewCell celda in fila.Cells)
                            {
                                tabla.AddCell(celda.Value?.ToString() ?? "");
                            }
                        }
                    }

                    pdf.Add(tabla);
                    pdf.Close();

                    MessageBox.Show("PDF exportado correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al exportar: " + ex.Message);
                }
            }
        }
    }
}

