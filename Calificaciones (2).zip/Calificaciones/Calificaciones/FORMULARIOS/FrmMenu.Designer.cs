﻿namespace $safeprojectname$.Formularios
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            menuStrip1 = new MenuStrip();
            inicioToolStripMenuItem = new ToolStripMenuItem();
            estudianteToolStripMenuItem = new ToolStripMenuItem();
            materiasToolStripMenuItem = new ToolStripMenuItem();
            calificacionesToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            btnExportar = new Button();
            dgvInicio = new DataGridView();
            button1 = new Button();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvInicio).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.HotTrack;
            menuStrip1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            menuStrip1.Items.AddRange(new ToolStripItem[] { inicioToolStripMenuItem, estudianteToolStripMenuItem, materiasToolStripMenuItem, calificacionesToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1018, 33);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // inicioToolStripMenuItem
            // 
            inicioToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            inicioToolStripMenuItem.Size = new Size(71, 29);
            inicioToolStripMenuItem.Text = "Inicio";
            inicioToolStripMenuItem.Click += inicioToolStripMenuItem_Click_1;
            // 
            // estudianteToolStripMenuItem
            // 
            estudianteToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            estudianteToolStripMenuItem.Name = "estudianteToolStripMenuItem";
            estudianteToolStripMenuItem.Size = new Size(122, 29);
            estudianteToolStripMenuItem.Text = "Estudiantes";
            estudianteToolStripMenuItem.Click += estudianteToolStripMenuItem_Click_1;
            // 
            // materiasToolStripMenuItem
            // 
            materiasToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            materiasToolStripMenuItem.Name = "materiasToolStripMenuItem";
            materiasToolStripMenuItem.Size = new Size(99, 29);
            materiasToolStripMenuItem.Text = "Materias";
            materiasToolStripMenuItem.Click += materiasToolStripMenuItem_Click_1;
            // 
            // calificacionesToolStripMenuItem
            // 
            calificacionesToolStripMenuItem.ForeColor = SystemColors.ButtonHighlight;
            calificacionesToolStripMenuItem.Name = "calificacionesToolStripMenuItem";
            calificacionesToolStripMenuItem.Size = new Size(141, 29);
            calificacionesToolStripMenuItem.Text = "$safeprojectname$";
            calificacionesToolStripMenuItem.Click += calificacionesToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(0, 75);
            label1.Name = "label1";
            label1.Size = new Size(410, 37);
            label1.TabIndex = 2;
            label1.Text = "$safeprojectname$ de los estudiantes";
            label1.Click += label1_Click;
            // 
            // btnExportar
            // 
            btnExportar.BackColor = Color.DarkOrange;
            btnExportar.ForeColor = SystemColors.ButtonFace;
            btnExportar.Location = new Point(893, 327);
            btnExportar.Name = "btnExportar";
            btnExportar.Size = new Size(102, 52);
            btnExportar.TabIndex = 36;
            btnExportar.Text = "Exportar";
            btnExportar.UseVisualStyleBackColor = false;
            btnExportar.Click += btnExportar_Click;
            // 
            // dgvInicio
            // 
            dgvInicio.AllowUserToOrderColumns = true;
            dgvInicio.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvInicio.Location = new Point(12, 385);
            dgvInicio.Name = "dgvInicio";
            dgvInicio.Size = new Size(983, 359);
            dgvInicio.TabIndex = 37;
            // 
            // button1
            // 
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.Location = new Point(12, 115);
            button1.Name = "button1";
            button1.Size = new Size(304, 202);
            button1.TabIndex = 38;
            button1.UseVisualStyleBackColor = true;
            // 
            // FrmMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.HighlightText;
            ClientSize = new Size(1018, 756);
            Controls.Add(button1);
            Controls.Add(dgvInicio);
            Controls.Add(btnExportar);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            ForeColor = SystemColors.ActiveCaptionText;
            MainMenuStrip = menuStrip1;
            Name = "FrmMenu";
            Load += FrmMenu_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvInicio).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem inicioToolStripMenuItem;
        private ToolStripMenuItem estudianteToolStripMenuItem;
        private ToolStripMenuItem materiasToolStripMenuItem;
        private ToolStripMenuItem calificacionesToolStripMenuItem;
        private Label label1;
        private Button btnExportar;
        private DataGridView dgvInicio;
        private Button button1;
    }
}