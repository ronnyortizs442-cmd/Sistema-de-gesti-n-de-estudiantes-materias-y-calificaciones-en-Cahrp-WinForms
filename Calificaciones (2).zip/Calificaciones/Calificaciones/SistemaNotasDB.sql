CREATE DATABASE SistemaNotasDB;

USE SistemaNotasDB;


CREATE TABLE Estudiante (
EstudianteID INT IDENTITY(1,1) PRIMARY KEY,
Nombre NVARCHAR(150) NOT NULL,
Correo NVARCHAR(120) NULL,
Matricula NVARCHAR(50) NULL,
FechaCreacion DATETIME DEFAULT GETDATE()
);


CREATE TABLE Materia (
MateriaID INT IDENTITY(1,1) PRIMARY KEY,
Nombre NVARCHAR(150) NOT NULL,
Descripcion NVARCHAR(500) NULL
);



CREATE TABLE Calificacion (
CalificacionID INT IDENTITY(1,1) PRIMARY KEY,
EstudianteID INT NOT NULL FOREIGN KEY REFERENCES Estudiante(EstudianteID),
MateriaID INT NOT NULL FOREIGN KEY REFERENCES Materia(MateriaID),
Cal1 DECIMAL(5,2) DEFAULT 0,
Cal2 DECIMAL(5,2) DEFAULT 0,
Cal3 DECIMAL(5,2) DEFAULT 0,
Cal4 DECIMAL(5,2) DEFAULT 0,
Examen DECIMAL(5,2) DEFAULT 0,
Total AS (Cal1 + Cal2 + Cal3 + Cal4 + Examen) PERSISTED,
Clasificacion AS (
CASE
WHEN (Cal1 + Cal2 + Cal3 + Cal4 + Examen) >= 90 THEN 'A'
WHEN (Cal1 + Cal2 + Cal3 + Cal4 + Examen) >= 80 THEN 'B'
WHEN (Cal1 + Cal2 + Cal3 + Cal4 + Examen) >= 70 THEN 'C'
WHEN (Cal1 + Cal2 + Cal3 + Cal4 + Examen) >= 60 THEN 'D'
ELSE 'F' END
) PERSISTED,
Estado AS (
CASE WHEN (Cal1 + Cal2 + Cal3 + Cal4 + Examen) >= 70 THEN 'Aprobado' ELSE 'Reprobado' END
) PERSISTED,
FechaRegistro DATETIME DEFAULT GETDATE()
);
