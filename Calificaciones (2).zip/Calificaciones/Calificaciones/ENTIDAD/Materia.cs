﻿namespace $safeprojectname$.Entidad
{
    public class Materia
    {
        public int MateriaID { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
    }
}
