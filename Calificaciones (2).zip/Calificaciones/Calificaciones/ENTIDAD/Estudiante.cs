﻿namespace $safeprojectname$.Entidad
{
    public class Estudiante
    {
        public int EstudianteID { get; set; }
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public string Matricula { get; set; }
    }

}
