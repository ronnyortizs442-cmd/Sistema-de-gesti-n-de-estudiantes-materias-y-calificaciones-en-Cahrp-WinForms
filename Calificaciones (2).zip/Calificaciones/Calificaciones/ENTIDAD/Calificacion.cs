﻿namespace $safeprojectname$.Entidad
{
    public class Calificacion
    {
        public int CalificacionID { get; set; }
        public int EstudianteID { get; set; }
        public int MateriaID { get; set; }
        public decimal Cal1 { get; set; }
        public decimal Cal2 { get; set; }
        public decimal Cal3 { get; set; }
        public decimal Cal4 { get; set; }
        public decimal Examen { get; set; }
        public decimal Total { get; set; }
        public string Clasificacion { get; set; } 
        public string Estado { get; set; } 
    }
}
